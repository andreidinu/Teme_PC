#include <stdio.h>
#include <stdlib.h>

// Primeste input-ul citit de fgets si stocheaza doar datele
// (fara spatiu) intr-un tablou. Functia intoarce nr de caractere prezente
// in tablou.
int lungime_vector(char input_original[100], char input_prelucrat[300][5])
{
	int len = 0;
	int i, j = 0;

	for(i = 0; ; i++)
	{
		if(input_original[i] != ' ')
		{
			input_prelucrat[len][j++] = input_original[i];
		}
		else
		{
			input_prelucrat[len][j++] = '\0';
			len++;
			j = 0;
		}
		if(input_original[i] == '\0')
		    break;
	}

	return len;	
}

// Dupa fiecare ciclu afisare, fagurele este "golit".
// Fiecare caracter se suprascrie cu spatiu.
void initializare_fagure(char fagure[100][100])
{
	int i, j;

	for(i = 0; i < 100; i++)
	{
		for(j = 0; j < 100; j++)
		{
			fagure[i][j] = ' ';
		}
	}
}

// Uneste underscore-urile intre ele, creand fagurele propriu zis
void unire_underscores(int index_fagure, float index, int j_max, char fagure[100][100], char linie_prelucrata[300][5])
{
	int i, j;
	
	for(j = 0; j <= j_max; j++)
	{
		if(j % 2 == 1)
		{
			index_fagure++;
		}
		for(i = 0; i <= atoi(linie_prelucrata[(int)index]) * 2; i++)
		{
			if(j % 2 == 1)
			{
				if(fagure[i][j] == '_' && fagure[i + 2][j] == '_')
				{
					fagure[i + 1][j - 1] = '/';
					fagure[i + 2][j - 1] = '\\';
					fagure[i + 1][j + 1] = '\\';
					fagure[i + 2][j + 1] = '/';
				}
			}
		}
		index += 0.5;
	}
}

// Afisare fagure
void afisare_faguri(int i_max, int j_max, char fagure[100][100])
{
	int i, j;

	for(i = 0; i <= i_max; i++)
	{
		for(j = 0; j <= j_max; j++)
		{
			printf("%c", fagure[i][j]);
		}
		printf("\n");
	}
}

int main()
{
	int i, j, i_max, j_max, lv;
	int nr_faguri = 0;
	int index_fagure = 0, index_caracter = 0;
	float index = 0.0;
	char linie[300];
	char linie_prelucrata[300][5];
	char fagure[100][100];
	char c;
	
	while(fgets(linie, 300, stdin))
	{
		lv = lungime_vector(linie, linie_prelucrata);
		
		for(i = 0; i <= lv; i++)
		{
			if(linie_prelucrata[i][0] == 'C' || linie_prelucrata[i][0] == 'R')
			{
				c = linie_prelucrata[i][0];
				break;
			}	
		}
		
		initializare_fagure(fagure); // Fagurele se umple cu caracterul spatiu

		i_max = 0;
		nr_faguri = 0;
		i = 0;
		while(linie_prelucrata[i][0] != c)
		{
			i++;
			nr_faguri++;
		}

		// Genereaza underscore-urile si le scrie in matrice
		index_fagure = 0;
		j_max = nr_faguri * 2;
		index = 0.0;
		for(j = 0; j <= j_max; j++)
		{	
			if(j % 2 == 1)
			{
				index_fagure++;
			}
			for(i = 0; i <= (atoi(linie_prelucrata[(int)index])) * 2; i++)
			{
				if(j % 2 == 1)
				{
					if(i % 2 == 0)
					{
						if(c == 'R')
						{
							if(index_fagure % 2 == 1)
							{
								fagure[i][j] = '_';
								if(i_max < i)
									i_max = i;
							}
							else
							{
								fagure[i + 1][j] = '_';
								if(i_max < i + 1)
									i_max = i + 1;
							}
						}
						else
						{
							if(index_fagure % 2 == 1)
							{
								fagure[i + 1][j] = '_';
								if(i_max < i + 1)
									i_max = i + 1;
							}
							else
							{
								fagure[i][j] = '_';
								if(i_max < i)
									i_max = i;
							}
						}
					}
				}
			}
			index += 0.5;
		}

		// Se unesc underscore-urile intre ele
		index_fagure = 0;
		index = 0.0;
		unire_underscores(index_fagure, index, j_max, fagure, linie_prelucrata);		

		// Aseaza reginele in faguri 
		index_caracter = 0;
		if(c != linie_prelucrata[lv][0]) // Verific mai intai daca exista regina in stup
		{
			while(linie_prelucrata[index_caracter][0] != c)
			{
				index_caracter++;
			}
			index_caracter++;

			while(index_caracter <= lv)
			{
				j = atoi(linie_prelucrata[index_caracter]) * 2 - 1;
				if(c == 'R')
				{
					if(j % 4 == 1)
					{
						i = atoi(linie_prelucrata[index_caracter + 1]) * 2 - 1;
					}
					else
					{
						i = atoi(linie_prelucrata[index_caracter + 1]) * 2;
					}
				}
				else
				{
					if(j % 4 == 1)
					{
						i = atoi(linie_prelucrata[index_caracter + 1]) * 2;
					}
					else
					{
						i = atoi(linie_prelucrata[index_caracter + 1]) * 2 - 1;
					}
				}
				fagure[i][j] = 'Q';
				index_caracter += 2;
			} 
		}
		
		afisare_faguri(i_max, j_max, fagure); // Se afiseaza fagurele complet, cu regine in el
	}

	return 0;
}

