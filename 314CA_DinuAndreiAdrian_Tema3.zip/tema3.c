#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct fabrici
{
	char oras[50];
	char jucarie[50];
	char directie;
	int jucarii_ramase;
};

struct livrari
{
	char loc[50];
	char cadou[100][50];
	char cadou_final[100][50];
	int freq[50];
	int freq_final[50];
	int nr_cadouri;
	int cadouri_unice;
};

int total_cadouri(int orase_vizitate, struct livrari *liv)
{
	int i;
	int cadouri_adunate = 0;

	for(i = 0; i < orase_vizitate; i++)
	{
		cadouri_adunate += liv[i].nr_cadouri;
	}

	return cadouri_adunate;
}

void ordonare_orase(int orase_vizitate, struct livrari *liv)
{
    int i, j;
    struct livrari temp;

    for(i = 0; i < orase_vizitate; i++)
    {
        for(j = 0; j < orase_vizitate - 1; j++)
        {
            if(strcmp(liv[j].loc, liv[j + 1].loc) > 0)
            {
                temp = liv[j];
                liv[j] = liv[j + 1];
                liv[j + 1] = temp;
            }
        }
    }
}

void ordonare_jucarii(int orase_vizitate, struct livrari *liv)
{
	int i, j, k;
	char temp[50];

	for(i = 0; i < orase_vizitate; i++)
	{
      	for(j = 0; j < liv[i].nr_cadouri; j++) 
      	{
      		for(k = 0; k < liv[i].nr_cadouri - 1; k++)
      		{
      			if(strcmp(liv[i].cadou[k], liv[i].cadou[k + 1]) > 0)
      			{
            		strcpy(temp, liv[i].cadou[k]);
            		strcpy(liv[i].cadou[k], liv[i].cadou[k + 1]);
            		strcpy(liv[i].cadou[k + 1], temp);
         		}
      		}
      	}
    }
}

void frecventa_jucarii(int orase_vizitate, struct livrari *liv)
{
	int i, j, k;
	int count;

	for(i = 0; i < orase_vizitate; i++)
	{
		for(j = 0; j < liv[i].nr_cadouri; j++)
		{
			liv[i].freq[j] = -1;
		}
	}

	for(i = 0; i < orase_vizitate; i++)
	{
		for(j = 0; j < liv[i].nr_cadouri; j++)
		{
			count = 1;
			for(k = j + 1; k < liv[i].nr_cadouri; k++)
			{
				if(strcmp(liv[i].cadou[j], liv[i].cadou[k]) == 0)
				{
					count++;
					liv[i].freq[k] = 0;
				}
			}
			if(liv[i].freq[j] != 0)
			{
				liv[i].freq[j] = count;
			}
		}
	}
}

void set_frecventa_jucarii(int orase_vizitate, struct livrari *liv)
{
	int i, j;

	for(i = 0; i < orase_vizitate; i++)
	{
		liv[i].cadouri_unice = 0;
		for(j = 0; j < liv[i].nr_cadouri; j++)
		{	
			if(liv[i].freq[j] != 0)
			{
				liv[i].freq_final[liv[i].cadouri_unice] = liv[i].freq[j];
				strcpy(liv[i].cadou_final[liv[i].cadouri_unice], liv[i].cadou[j]);
				liv[i].cadouri_unice++;
			}
		}
	}
}

void ordonare_descrescatoare(int orase_vizitate, struct livrari *liv)
{
	char temp[50];
	int i, j, k;
	int val_temp;

	for(i = 0; i < orase_vizitate; i++)
	{
		for(j = 0; j < liv[i].cadouri_unice; j++)
		{
			for(k = 0; k < liv[i].cadouri_unice - 1; k++)
			{
				if(liv[i].freq_final[k] < liv[i].freq_final[k + 1])
				{
					val_temp = liv[i].freq_final[k];
					liv[i].freq_final[k] = liv[i].freq_final[k + 1];
					liv[i].freq_final[k + 1] = val_temp;
					
					strcpy(temp, liv[i].cadou_final[k]);
					strcpy(liv[i].cadou_final[k], liv[i].cadou_final[k + 1]);
					strcpy(liv[i].cadou_final[k + 1], temp);
				}
			}
		}
	}
}

void afisare_livrari(int orase_vizitate, struct livrari *liv)
{
	int i, j;

	for(i = 0; i < orase_vizitate; i++)
	{
		printf("%s:\n", liv[i].loc);
		for(j = 0; j < liv[i].cadouri_unice; j++)
		{
			printf("  %d %s\n", liv[i].freq_final[j], liv[i].cadou_final[j]);
		}
	}
}

int main()
{
	struct fabrici **fab;
	struct livrari *liv;

	int n, m, x, y;
	int i, j, k;
	int nr_pasi, pasi_facuti = 0;
	int cadouri_unice = 0, orase_vizitate = 0;
	int val_temp;

	char city[50], toy[50], temp[50];
	char dir;
	int jucarii;
	int test;

	scanf("%d %d", &n, &m);
	scanf("%d %d", &x, &y);
	scanf("%d", &nr_pasi);

	// Aloc memorie pentru harta fabricilor si pentru structurile finale
	fab = (struct fabrici **) malloc(n * sizeof(struct fabrici *));
	for(i = 0; i < n; i++)
	{
		fab[i] = (struct fabrici *) malloc(m * sizeof(struct fabrici));
	}
	
	liv = (struct livrari *) malloc(n * m * sizeof(struct livrari));
	
	for(i = 0; i < n; i++)
	{
		for(j = 0; j < m; j++)
		{
			scanf("%s", city);
			scanf("%s", toy);
			scanf("%d", &jucarii);
			scanf(" %c", &dir);

			strcpy(fab[i][j].oras, city);
			strcpy(fab[i][j].jucarie, toy);
			fab[i][j].jucarii_ramase = jucarii;
			fab[i][j].directie = dir;
		}
	}

	// Verific daca in locatia de plecare exista cadouri
	// Daca exista, initializez primul oras
	if(fab[x][y].jucarii_ramase > 0)
	{
		liv[0].nr_cadouri = 0;
		strcpy(liv[0].loc, fab[x][y].oras);
		strcpy(liv[0].cadou[0], fab[x][y].jucarie);
		fab[x][y].jucarii_ramase--;
		liv[0].nr_cadouri++;
		orase_vizitate++;
	}
	while(nr_pasi > 0) // Completarea hartii cu fabrici
	{
		if(fab[x][y].directie == 'U')
		{
			x--;
		}
		else if(fab[x][y].directie == 'D')
		{
			x++;
		}
		else if(fab[x][y].directie == 'L')
		{
			y--;
		}
		else 
		{
			y++;
		}
		nr_pasi--;
		
		if(x == -1 || y == -1 || x == n || y == m)
		{
			printf("TOO MUCH SNOW !\n");
			break;
		}
		else
		{	
			test = 0;
			for(i = 0; i < orase_vizitate; i++)
			{
				if(strcmp(liv[i].loc, fab[x][y].oras) == 0)
				{
					if(fab[x][y].jucarii_ramase > 0)
					{
						strcpy(liv[i].cadou[liv[i].nr_cadouri], fab[x][y].jucarie);
						liv[i].nr_cadouri++;
						fab[x][y].jucarii_ramase--;
					}
					test = 1;
					break;
				}
			}
			if(test == 0)
			{
				liv[orase_vizitate].nr_cadouri = 0;
				if(fab[x][y].jucarii_ramase > 0)
				{
					strcpy(liv[orase_vizitate].loc, fab[x][y].oras);
					strcpy(liv[orase_vizitate].cadou[0], fab[x][y].jucarie);
					liv[orase_vizitate].nr_cadouri++;
					fab[x][y].jucarii_ramase--;
					orase_vizitate++;
				}
			}
			pasi_facuti++;
		}
	}
	printf("%d\n", pasi_facuti); // Afisez nr. de pasi parcursi de Mos Craciun
	printf("%d\n", total_cadouri(orase_vizitate, liv)); // Afisez nr. de cadouri adunate
	
	// Redimensionez vectorul de structuri livrari marimea necesara
	liv = (struct livrari*) realloc(liv, orase_vizitate * sizeof(struct livrari));

	// Ordonarea structurilor dupa orasul destinatie
	ordonare_orase(orase_vizitate, liv);

	/*
	Ordonarea alfabetica a jucariilor din fiecare oras. Initial nu vom tine cont de nr de aparitii al unei jucarii,
	ordonarea se va face strict alfabetic. Vom trata ulterior cazurile de ordonare descrescatoare
	*/
	ordonare_jucarii(orase_vizitate, liv);

	/*
	Vector de frecventa pentru jucarii
	Va retine nr de aparatii al fiecarei jucarii
	*/
	frecventa_jucarii(orase_vizitate, liv);

	/*
	Vom retine doar cate o aparitie a fiecarei jucarii distincte
	si de cate ori se intalneste. Duplicatele vor fi ignorate.
	*/
	set_frecventa_jucarii(orase_vizitate, liv);

	// Ordonare descrescatoare in functie de nr. de aparitii al fiecarei jucarii
	ordonare_descrescatoare(orase_vizitate, liv);	

	// Afisare (oras/nr. cadouri/cadou)
	afisare_livrari(orase_vizitate, liv);

	// Eliberez memoria alocata dinamic
	for(i = 0; i < n; i++)
	{
		free(fab[i]);
	}
	free(fab);
	free(liv);

	return 0;
}

