#include <stdio.h>
#include <math.h>

// Normez red, green si blue
float normare_red(int red)
{
	return (float)red / 255;
}

float normare_green(int green)
{
	return (float)green / 255;
}

float normare_blue(int blue)
{
	return (float)blue / 255;
}

// Calculez valoarea maxima a celor 3
float c_max(float red_normat, float green_normat, float blue_normat)
{
    if(red_normat >= green_normat && red_normat >= blue_normat)
    {
        return red_normat;
    }
    else if(green_normat >= red_normat && green_normat >= blue_normat)
    {
        return green_normat;
    }
    else
    {
        return blue_normat;
    }
}

// Calculez valoarea minima a celor 3
float c_min(float red_normat, float green_normat, float blue_normat)
{
    if(red_normat <= green_normat && red_normat <= blue_normat)
    {
        return red_normat;
    }
    else if(green_normat <= red_normat && green_normat <= blue_normat)
    {
        return green_normat;
    }
    else
    {
        return blue_normat;
    }
}

// Calculez hue cu ajutorul noilor valori
float calc_hue(float delta, float red_normat, float green_normat, float blue_normat, float cmax)
{
    if(delta == 0)
    {
        return 0;
    }
    else if(cmax == red_normat)
    {
        return 60 * fmod(((green_normat - blue_normat) / delta), 6);
    }
    else if(cmax == green_normat)
    {
        return 60 * (((blue_normat - red_normat) / delta) + 2);
    }
    else
    {
        return 60 * (((red_normat - green_normat) / delta) + 4);
    }
}

// Calculez saturatia cu ajotorul formulei
float calc_saturation(float delta, float cmax)
{
    if(cmax == 0)
    {
        return 0;
    }
    else
    {
        return (delta / cmax);
    }
}

float calc_value(float cmax)
{
    return cmax;
}

int main()
{
    int counter, width, height, red, green, blue;
    char operation;
    float mult_factor, red_normat, green_normat, blue_normat;
    float cmin, cmax, delta;
    float hue, saturation, value;

    scanf("%d", &width);
    scanf("%d", &height);
    scanf(" %c", &operation);
    scanf("%f", &mult_factor);
  
    // Incep parcurgerea perechilor (R, G, B)
    for(counter = 0; counter < width * height; counter++)
    {
        scanf("%d", &red);
        scanf("%d", &green);
        scanf("%d", &blue);

        red_normat = normare_red(red);
        blue_normat = normare_blue(blue);
        green_normat = normare_green(green);
	
        cmin = c_min(red_normat, green_normat, blue_normat);
        cmax = c_max(red_normat, green_normat, blue_normat);

        delta = cmax - cmin;

	// Caut operatia corespunzatoare si efectuez transformarea in (H, S, V)
        if(operation == 'h')
        {
            hue = calc_hue(delta, red_normat, green_normat, blue_normat, cmax);
            saturation = calc_saturation(delta, cmax);
            value = calc_value(cmax);
		
            if(hue < 0)
            {
                hue += 360;
            }
            hue /= 360;
           

	    if(hue > 1)
	    {
		hue = 1;
            }

	    hue = (hue + mult_factor > 1) ? 1 : (hue + mult_factor);
            

            if(hue < 0)
	    {
	        hue = 0;
	    }

	  
            printf("%.5f ", hue);
            printf("%.5f ", saturation);
            printf("%.5f\n", value);

        }
        else if(operation == 's')
        {
            hue = calc_hue(delta, red_normat, green_normat, blue_normat, cmax);
            saturation = calc_saturation(delta, cmax);
            value = calc_value(cmax);
            
            if(hue < 0)
            {
                hue += 360;
            }
	    hue /= 360;
            
	    if(hue > 1)
            {
		hue = 1;
            }

	    saturation = (saturation * mult_factor > 1) ? 1 : (saturation * mult_factor);
		
            printf("%.5f ", hue);
            printf("%.5f ", saturation);
            printf("%.5f\n", value);

        }
        else if(operation == 'v')
        {
            hue = calc_hue(delta, red_normat, green_normat, blue_normat, cmax);
            saturation = calc_saturation(delta, cmax);
            value = calc_value(cmax);

            if(hue < 0)
            {
                hue += 360;
            }
            hue /= 360;
            
            if(hue > 1)
            {
		hue = 1;
            }

            value = (value * mult_factor > 1) ? 1 : (value * mult_factor);
          
            printf("%.5f ", hue);
            printf("%.5f ", saturation);
            printf("%.5f\n", value);
	    
        }
	else
	{
	    printf("OPERATIE NEDEFINTA\n");
            return -1;
	}

    }

    return 0;
}
